﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam.Core
{
    public class BMICalculator
    {
        // Hàm tính BMI
        public double Calculate(double weight, double height)
        {
            if (weight <= 0 || height <= 0)
                throw new ArgumentException("Weight and Height must be positive.");

            double bmi = weight / (height * height);
            return Math.Round(bmi, 1);
        }

        // Hàm phân loại BMI
        public string GetCategory(double bmi)
        {
            if (bmi < 18.5) return "Underweight";
            if (bmi < 25) return "Normal";
            if (bmi < 30) return "Overweight";
            return "Obese";
        }
    }
}
