﻿using Exam.Core;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam.Tests
{
    [TestFixture]
    public class BMICalculatorTests
    {
        // CÂU 1: Test tính toán BMI đúng
        [TestCase(70, 1.75, 22.9)]
        [TestCase(60, 1.60, 23.4)]
        [TestCase(80, 1.80, 24.7)]
        public void Calculate_ValidWeightAndHeight_ReturnsCorrectBMI(
            double weight, double height, double expectedBMI)
        {
            // Arrange
            var calculator = new BMICalculator();

            // Act
            double actualBMI = calculator.Calculate(weight, height);

            // Assert
            Assert.That(actualBMI, Is.EqualTo(expectedBMI).Within(0.1));
        }
        // CÂU 2: Test GetCategory với 5+ bộ dữ liệu
        [TestCase(17.0, "Underweight")]
        [TestCase(22.0, "Normal")]
        [TestCase(27.0, "Overweight")]
        [TestCase(32.0, "Obese")]
        [TestCase(18.5, "Normal")]
        [TestCase(24.9, "Normal")]
        [TestCase(25.0, "Overweight")]
        [TestCase(29.9, "Overweight")]
        [TestCase(30.0, "Obese")]
        public void GetCategory_VariousBMIValues_ReturnsCorrectCategory(
            double bmi, string expectedCategory)
        {
            // Arrange
            var calculator = new BMICalculator();

            // Act
            string actualCategory = calculator.GetCategory(bmi);

            // Assert
            Assert.That(actualCategory, Is.EqualTo(expectedCategory));
        }
        // CÂU 3: Test ArgumentException với Constraint Model
        // Weight
        [Test]
        public void Calculate_WeightIsZero_ThrowsArgumentException()
        {
            // Arrange
            var calculator = new BMICalculator();

            // Act & Assert
            Assert.That(
                () => calculator.Calculate(0, 0),
                Throws.TypeOf<ArgumentException>()
                    .With.Message.Contains("Weight and Height must be positive")
            );
        }

        // Height
        [Test]
        public void Calculate_HeightIsZero_ThrowsArgumentException_DEMO_FAIL()
        {
            // Arrange
            var calculator = new BMICalculator();

            // Act & Assert - Test sai: mong đợi không có exception
            Assert.That(
                () => calculator.Calculate(70, 0),
                Throws.Nothing  
            );
        }

        [Test]
        public void Calculate_BothZero_ThrowsArgumentException()
        {
            // Arrange
            var calculator = new BMICalculator();

            // Act & Assert
            Assert.That(
                () => calculator.Calculate(0, 0),
                Throws.TypeOf<ArgumentException>()
            );
        }
        // CÂU 4: Sử dụng ExpectedResult
        [TestCase(70, 1.75, ExpectedResult = 22.9)]
        [TestCase(60, 1.60, ExpectedResult = 23.4)]
        [TestCase(80, 1.80, ExpectedResult = 24.7)]
        [TestCase(55, 1.65, ExpectedResult = 20.2)]
        public double Calculate_UsingExpectedResult_ReturnsCorrectBMI(
            double weight, double height)
        {
            // Arrange
            var calculator = new BMICalculator();

            // Act
            double bmi = calculator.Calculate(weight, height);

            // Return để NUnit tự so sánh với ExpectedResult
            return System.Math.Round(bmi, 1);
        }
        // CÂU 5
        [TestCase(17.0, ExpectedResult = "Underweight")]
        [TestCase(16.5, ExpectedResult = "Underweight")]
        [TestCase(18.4, ExpectedResult = "Underweight")]
        public string GetCategory_UnderweightBMI_ReturnsUnderweight(double bmi)
        {
            var calculator = new BMICalculator();
            return calculator.GetCategory(bmi);
        }
    }
}